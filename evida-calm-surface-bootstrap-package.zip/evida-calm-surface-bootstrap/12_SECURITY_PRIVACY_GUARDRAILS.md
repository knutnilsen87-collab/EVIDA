# 12 Security og privacy guardrails

## Status

Evida skal behandles som pre-alpha/evaluation build til produksjonskrav er oppfylt.

Default copy:

```text
Evaluation build
Bruk testdata. Dokumentene behandles lokalt på denne maskinen. Ikke bruk reelle klientdata uten særskilt avtale.
```

## Prinsipper

- Lokal behandling som standard.
- Ekstern AI av som standard.
- Ikke send rå dokumenttekst til ekstern AI som default.
- Ikke logg sensitiv dokumenttekst.
- Ikke vis secrets.
- Ikke push til Git automatisk.
- Ikke gjør destruktive handlinger uten eksplisitt approval.

## Protected files

Ikke rør uten eksplisitt godkjenning:

```text
.env
.env.*
*.pem
*.key
id_rsa
id_ed25519
credentials.*
secrets.*
production config files
private customer data
```

## Approval pattern

Før skrive-/execute-handlinger:

```text
Action:
Files/commands:
Risk:
Why needed:
Rollback:
Tests:
Approve? [Yes/No/Edit]
```

## Manual review audit

Hver dokumentbeslutning bør audit-logges:

```ts
interface ManualReviewAuditEvent {
  documentId: string;
  decision:
    | "approve_as_source"
    | "reviewed_not_citable"
    | "exclude_from_case"
    | "replace_file"
    | "skip_duplicate";
  previousState: string;
  nextState: string;
  actor: "local_user";
  timestamp: string;
}
```

## No fake citations

Hard rule:

```text
Hvis kilde mangler, vis `Mangler kilde`.
Ikke lag fiktive kildechips.
```

## External AI

Hvis ekstern AI senere aktiveres:

- krever eksplisitt opt-in
- forklarer hva som sendes ut
- viser kildepolicy
- tillater avbrudd
- logger policy decision
- aldri sender secrets eller full dokumentpakke uten tydelig separat godkjenning
