# 04 Komponentspesifikasjoner

## 1. `ReadinessStatusCard`

### Formål

Alltid svare på:

```text
Hva skjer nå?
Hva mangler?
Hva skal jeg gjøre?
```

### Props

```ts
interface ReadinessStatusCardProps {
  readiness: CaseReadiness;
  onPrimaryAction: (action: NextActionKey) => void;
  onShowDetails?: () => void;
}
```

### UI

```text
[status badge]
Tittel

Kort forklaring.
Hvis relevant: 2 dokumenter gjenstår.

[Primær CTA] [Vis detaljer]
```

### Eksempel

```text
Kontroll kreves

6 dokumenter må vurderes før Saksrom kan åpnes.
Neste steg: kontroller dokumentene som mangler lesbar tekst.

[Start kontroll] [Vis detaljer]
```

### Acceptance criteria

- én primær CTA
- ingen tekniske begreper i default copy
- `Vis detaljer` er sekundær
- status oppdateres ved import/control changes

---

## 2. `CalmSidebar`

### Formål

Redusere navigasjonsstøy.

### Regler

Vis få hovedvalg:

```text
Sak
Dokumenter
Kontroll
Saksrom
Analyse
Eksport
```

Ikke vis alle analyseundermoduler i første flyt.

### Unlock

```ts
interface SidebarItem {
  key: ViewKey;
  label: string;
  visible: boolean;
  enabled: boolean;
  lockedReason?: string;
  onLockedClickTarget?: ViewKey;
}
```

### Locked click

Klikk på låst Saksrom skal ikke gjøre ingenting. Det skal rute til riktig neste steg og vise readiness-boks.

---

## 3. `ImportStatusCard`

### Formål

Gi trygg venting.

### Default data

```text
Saken klargjøres
Evida leser dokumenter og bygger sporbare kilder.

11 av 21 dokumenter
84 av 167 sider
214 kilder funnet
Fase: Henter tekst
Ca. 1 min igjen
```

### Regler

- ETA kun mens `progress < 100` og import aktiv.
- Hvis ferdig: `Ferdig`, ikke `ETA beregnes`.
- Lang dokumentliste bak `Vis detaljer`.

---

## 4. `DocumentControlView`

### Layout

```text
+---------------------+----------------------------+----------------------+
| Dokumentkø          | Preview                    | Beslutning           |
|                     |                            |                      |
| IMG_001.jpg         | valgt dokument             | Godkjenn som kilde   |
| Mangler tekst       |                            | Kontrollert, ikke... |
+---------------------+----------------------------+----------------------+
```

### Props

```ts
interface DocumentControlViewProps {
  documents: ReviewDocument[];
  selectedDocumentId?: string;
  selectedIds: string[];
  onSelectDocument: (id: string) => void;
  onToggleSelected: (id: string) => void;
  onDecision: (decision: ReviewDecisionInput) => void;
  onBulkDecision: (decision: BulkReviewDecisionInput) => void;
}
```

### Acceptance criteria

- valgt dokument vises i midtpanelet
- ingen Windows Utforsker åpnes som default
- rader er korte
- teknisk info bak `Vis detaljer`
- neste dokument velges automatisk etter beslutning

---

## 5. `DocumentQueue`

### Radcopy

```text
IMG_001.jpg
Mangler tekst
```

Statuslabels:

```text
Klar som kilde
Mangler tekst
Delvis lesbar
Duplikat
Feilet import
Ikke støttet
Kontrollert, ikke siterbar
Ikke brukt
```

### Accessibility

- `role="listbox"` eller passende list semantics
- valgt rad: `aria-selected`
- checkbox: `aria-checked`
- pil opp/ned navigerer
- Enter åpner/velger rad

---

## 6. `DocumentPreviewPanel`

### Formål

Brukeren må se dokumentet inne i appen.

### States

```text
preview_ready
text_fallback
image_preview
pdf_preview
unsupported_preview
loading
error
```

### Fallback copy

```text
Forhåndsvisning er ikke tilgjengelig.
Du kan fortsatt velge om dokumentet skal erstattes eller holdes utenfor saken.
```

---

## 7. `DocumentDecisionPanel`

### Regler

Ikke bruk `Godkjenn` alene.

### Dokument med kilder

Primær:

```text
Godkjenn som kilde
Dokumentet kan brukes i Saksrom-svar med kildehenvisning.
```

Sekundær:

```text
Ikke bruk i saken
Erstatt fil
```

### Dokument uten lesbar tekst

Primær:

```text
Kontrollert, men ikke siterbar
Dokumentet er håndtert, men brukes ikke som AI-kilde i Saksrom.
```

Sekundær:

```text
Erstatt fil
Ikke bruk i saken
```

### Duplikat

Primær:

```text
Ikke bruk duplikat
Hindrer at samme dokument teller dobbelt i saken.
```

Sekundær:

```text
Åpne original
Erstatt fil
```

---

## 8. `BulkActionBar`

### Trigger

Vises når `selectedIds.length > 0`.

### UI

```text
5 dokumenter valgt

[Godkjenn valgte som kilde]
[Kontrollert, men ikke siterbar]
[Ikke bruk valgte]
[Fjern valg]
```

### Hard rule

Hvis ett valgt dokument ikke har source objects:

```text
Deaktiver: Godkjenn valgte som kilde
Tooltip/copy: 2 valgte dokumenter mangler lesbar tekst og kan ikke godkjennes som kilder.
```

### Bekreftelse

```text
Du markerer 5 dokumenter som kontrollert, men ikke siterbare.
De blir ikke brukt som AI-kilder i Saksrom.

[Bekreft] [Avbryt]
```

---

## 9. `CaseRoomGate`

### Blocked state

```text
Saksrom er ikke klart ennå

Dokumentene er importert, men Evida mangler sporbare kildeutdrag.
Kontroller eller erstatt dokumentene før du stiller spørsmål om saken.

[Åpne kontroll]
```

### Ready state

Render `CaseRoomView`.

---

## 10. `CaseRoomSourceSummary`

### Før første spørsmål

```text
Saksrom er klart

Svar bygger på 12 godkjente kilder.
3 dokumenter er ikke brukt fordi de mangler lesbar tekst.

[Vis kildegrunnlag]
```

### Etter svar

```text
Dette svaret bruker 4 kilder.
2 dokumenter er fortsatt ikke siterbare.
```

---

## 11. `CitationChip`

### UI

```text
[Kilde 1 · side 4]
```

### Click/keyboard

Åpner kildekort:

```text
Dokument: Leiekontrakt.pdf
Side: 4
Utdrag: ...
[Åpne i preview]
```

### Accessibility

- `<button>` ikke `<span>`
- `aria-label="Åpne kilde Leiekontrakt.pdf side 4"`
- Enter/Space aktiverer
