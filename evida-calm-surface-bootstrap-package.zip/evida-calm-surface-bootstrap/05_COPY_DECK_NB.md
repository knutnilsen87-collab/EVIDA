# 05 Copydeck norsk bokmål

Bruk disse tekstene konsekvent.

## Global tone

```text
rolig
presis
kort
ikke-teknisk
juridisk trygg
ingen AI-hype
```

## Start / ny sak

### Tittel

```text
Velkommen til Evida
```

### Body

```text
Opprett en sak og legg til dokumentene dine. Saksrom åpnes når dokumentgrunnlaget er klart.
```

### CTA

```text
Opprett ny sak
```

## Første dokumentimport

### Privacy/pre-alpha notice

```text
Evaluation build

Bruk testdata. Dokumentene behandles lokalt på denne maskinen. Ikke bruk reelle klientdata uten særskilt avtale.
```

### CTA

```text
Legg til dokumenter
```

### Secondary

```text
Dra filer hit
```

## Import

### Active

```text
Saken klargjøres

Evida leser dokumenter og bygger sporbare kilder.
```

### Counts

```text
{processedDocuments} av {totalDocuments} dokumenter behandlet
{processedPages} av {totalPages} sider lest
{sourceObjects} kildeutdrag funnet
Fase: {phase}
Ca. {eta} igjen
```

### Done

```text
Klargjøring ferdig
```

### Done with control

```text
Kontroll kreves

{count} dokumenter må vurderes før Saksrom kan åpnes.
```

### CTA

```text
Start kontroll
```

## Readiness states

### No documents

```text
Legg til dokumenter

Saksrom åpnes når Evida har bygget sporbare kilder fra dokumentene.
```

CTA:

```text
Legg til dokumenter
```

### Importing

```text
Saken klargjøres

Evida leser dokumenter og bygger sporbare kilder.
```

CTA:

```text
Vis behandlingsstatus
```

### Needs control

```text
Kontroll kreves

{count} dokumenter må vurderes før Saksrom kan åpnes.
```

CTA:

```text
Start kontroll
```

### Needs sources

```text
Kildegrunnlag mangler

Dokumentene er importert, men Evida mangler sporbare kildeutdrag.
```

CTA:

```text
Åpne kontroll
```

### Ready

```text
Saken er klar

Evida har bygget sporbare kilder fra dokumentene. Du kan nå stille spørsmål i Saksrom.
```

CTA:

```text
Åpne Saksrom
```

## Locked Saksrom

```text
Saksrom er låst foreløpig

Vi må først sikre at dokumentgrunnlaget er klart.
Neste steg: {nextStep}.
```

CTA examples:

```text
Legg til dokumenter
Start kontroll
Åpne kontroll
```

## Dokumentkontroll

### Page title

```text
Dokumentkontroll
```

### Subtitle

```text
Kontroller bare dokumentene som trenger en beslutning.
```

### Empty state

```text
Ingen dokumenter trenger kontroll

Saken er klar til Saksrom.
```

CTA:

```text
Åpne Saksrom
```

### Row labels

```text
Klar som kilde
Mangler tekst
Delvis lesbar
Duplikat
Feilet import
Ikke støttet
Kontrollert, ikke siterbar
Ikke brukt
```

## Decision copy

### Document has sources

Button:

```text
Godkjenn som kilde
```

Helper:

```text
Dokumentet kan brukes i Saksrom-svar med kildehenvisning.
```

### Document lacks readable text

Button:

```text
Kontrollert, men ikke siterbar
```

Helper:

```text
Dokumentet er håndtert, men brukes ikke som AI-kilde i Saksrom.
```

### Exclude

Button:

```text
Ikke bruk i saken
```

Helper:

```text
Dokumentet holdes utenfor analyse og Saksrom.
```

### Replace

Button:

```text
Erstatt fil
```

Helper:

```text
Last opp en ny versjon av dokumentet.
```

### Duplicate

Button:

```text
Ikke bruk duplikat
```

Helper:

```text
Hindrer at samme dokument teller dobbelt i saken.
```

## Bulk

### Bar

```text
{count} dokumenter valgt
```

### Confirm approve as source

```text
Du godkjenner {count} dokumenter som kilder.
Dokumentene kan brukes i Saksrom-svar med kildehenvisning.
```

### Confirm controlled not citable

```text
Du markerer {count} dokumenter som kontrollert, men ikke siterbare.
Dokumentene blir ikke brukt som AI-kilder i Saksrom.
```

### Confirm exclude

```text
Du holder {count} dokumenter utenfor saken.
De blir ikke brukt i analyse eller Saksrom.
```

### Confirm buttons

```text
Bekreft
Avbryt
```

## Saksrom

### Ready header

```text
Saksrom
Svar bygger på kontrollerte kilder i saken.
```

### Source summary

```text
Dette Saksrommet bygger på {sourceCount} godkjente kilder.
{notCitableCount} dokumenter er ikke brukt fordi de mangler lesbar tekst.
```

### Input placeholder

```text
Still et spørsmål om saken …
```

### Empty suggested questions

```text
Hva handler saken om?
Hva er dokumentert?
Hva mangler?
Hva bør kontrolleres først?
```

### Missing source

```text
Jeg kan ikke kildeverifisere dette med tilgjengelige dokumenter.
```

### Answer source summary

```text
Dette svaret bruker {count} kilder.
```

### Details label

```text
Kilder, usikkerhet og neste steg
```

## What not to write

Ikke bruk:

```text
Readiness false
sourceObjectsCount
OCR failed
chunking done
provider error
AI har analysert saken
Alt ser bra ut
Godkjenn
Fortsett
OK
```

Bruk brukerorienterte forklaringer.
