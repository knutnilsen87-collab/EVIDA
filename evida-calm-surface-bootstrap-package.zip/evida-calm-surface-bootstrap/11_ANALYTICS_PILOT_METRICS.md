# 11 Pilotmålinger og analytics

Dette er målinger for første pilot. De må ikke samle sensitiv dokumenttekst.

## Viktige events

```ts
type EvidaPilotEvent =
  | "case_created"
  | "documents_import_started"
  | "documents_import_completed"
  | "documents_import_failed"
  | "readiness_status_seen"
  | "locked_case_room_clicked"
  | "document_control_started"
  | "document_decision_made"
  | "bulk_action_started"
  | "bulk_action_confirmed"
  | "case_room_opened"
  | "case_room_question_asked"
  | "citation_chip_clicked"
  | "source_summary_opened"
  | "export_started";
```

## Event payload-regler

Ikke logg:

```text
dokumenttekst
personnavn
klientnavn
full filsti
rå juridisk innhold
```

Tillatt:

```text
case_id hashed/local
counts
status
duration_ms
decision_type
source_count
document_count
pending_control_count
```

## Minimum payload

```ts
interface SafePilotEventPayload {
  event: EvidaPilotEvent;
  timestamp: string;
  caseIdHash?: string;
  counts?: {
    documents?: number;
    sources?: number;
    pendingControl?: number;
    selected?: number;
  };
  readinessStatus?: string;
  decisionType?: string;
  durationMs?: number;
}
```

## Metrikker

| Metrikk | Hvorfor |
|---|---|
| Time to first value | Tid til nyttig Saksrom-verdi |
| Import abandonment | Om import skaper usikkerhet |
| Kontroll completion rate | Viktigste flaskehals |
| Tid per kontrollert dokument | Effektivitet i review-kø |
| Bulk usage rate | Om bulk føles trygt |
| Bulk cancel rate | Om bulkcopy skaper usikkerhet |
| Locked Saksrom clicks | Om readiness forstås |
| Citation chip CTR | Om kilder brukes |
| Decision reversal rate | Om copy/handlinger misforstås |
| Trust score after first answer | Kritisk for juridisk AI-produkt |

## A/B-test hypoteser

### Test 1 — Readiness card

Hypotese:
Hvis readiness vises som én handlingsboks med årsak og neste steg, vil flere brukere gå til riktig neste handling og færre klikke gjentatte ganger på låst Saksrom.

Mål:

- CTR på primær CTA
- locked_case_room_clicked
- supportspørsmål
- time to control start

### Test 2 — Decision copy

Hypotese:
Hvis `Marker kontrollert` erstattes med `Kontrollert, men ikke siterbar`, vil feilbeslutninger og reversals gå ned.

Mål:

- decision reversal rate
- time per decision
- wrong approve rate
- user confidence rating

### Test 3 — First answer source summary

Hypotese:
Hvis første Saksrom-opplevelse viser kildeoppsummering og citation chips, øker videre bruk.

Mål:

- follow-up questions
- citation chip CTR
- source summary opens
- export/analysis start
