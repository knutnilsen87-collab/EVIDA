# 01 Produktregler

Dette dokumentet er styrende. Når eldre dokumentasjon eller eksisterende UI bryter med disse reglene, skal dette dokumentet vinne.

## Non-negotiables

### 1. Saksrom åpnes ikke som full arbeidsflate før saken har kildegrunnlag

Minimum:

```ts
hasSources === true
unresolvedControlDocuments === 0
isImporting === false
```

Hvis dette ikke er sant, skal Saksrom enten være låst eller vise en trygg preview/blocked state uten fri spørsmålsinput.

### 2. Brukeren skal aldri måtte gjette hva en dokumenthandling betyr for Saksrom

Hver beslutning må si konsekvensen.

Ikke:

```text
Godkjenn
Marker kontrollert
OK
```

Bruk:

```text
Godkjenn som kilde
Kontrollert, men ikke siterbar
Ikke bruk i saken
Erstatt fil
```

### 3. Teknisk informasjon er sekundær

Følgende skal ikke være default på hovedflaten:

```text
OCR-koder
hash
source IDs
chunk IDs
database state
audit event names
full filsti
debug warnings
provider errors
```

Bruk `Vis detaljer`.

### 4. Importstatus skal være stabil og rolig

Default:

```text
Saken klargjøres
Evida leser dokumenter og bygger sporbare kilder.

11 av 21 dokumenter behandlet
84 av 167 sider lest
214 kildeutdrag funnet
Ca. 1 min igjen
```

Regler:

- Ikke vis ETA når import er ferdig.
- Ikke vis `ETA beregnes ...` ved 100 %.
- Ikke bytt mellom store skjermbilder under import.
- Ikke vis lang dokumentliste som default.

### 5. Dokumentkontroll er en kø, ikke et administrasjonspanel

Layout:

```text
Venstre: dokumentkø
Midten: preview
Høyre: beslutning
```

Hver rad:

```text
IMG_001.jpg
Mangler tekst
```

### 6. Bulk er lov, men må være trygt

Bulk må vise:

```text
antall valgte
hva handlingen gjør
om dokumentene blir siterbare eller ikke
mulighet til å avbryte
audit per dokument
```

Bulk-regel:

```text
Ikke vis “Godkjenn valgte som kilde” hvis noen valgte dokumenter mangler source_count.
```

### 7. Saksrom må bygge tillit med sporbarhet

Første opplevelse i Saksrom bør vise:

```text
Dette Saksrommet bygger på 12 godkjente kilder.
3 dokumenter brukes ikke fordi de mangler lesbar tekst.
```

Alle kildebaserte påstander må ha citation chips. Manglende kildegrunnlag må vises eksplisitt.

### 8. Pre-alpha/privacy skal forklares rolig før første import

Ikke skremmende modal. Bruk rolig informasjonsboks:

```text
Evaluation build
Bruk testdata. Dokumentene behandles lokalt. Ikke bruk reelle klientdata uten avtale.
```

### 9. Én primærhandling per skjerm

Hver skjerm må ha én tydelig CTA:

- `Legg til dokumenter`
- `Start kontroll`
- `Åpne Saksrom`
- `Godkjenn som kilde`
- `Erstatt fil`

### 10. Premium-følelse kommer fra fravær av støy

Brukeren skal oppleve:

```text
rolig
presis
juridisk trygg
ikke teknisk
ikke masete
ikke dashboard-tung
```
