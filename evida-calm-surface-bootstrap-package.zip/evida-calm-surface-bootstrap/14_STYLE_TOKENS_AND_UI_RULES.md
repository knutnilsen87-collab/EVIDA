# 14 Style tokens og UI-regler

## Mål

Evida skal føles:

```text
rolig
presis
juridisk trygg
nordisk
ikke dashboard-tung
ikke AI-hypet
```

## UI-regler

### 1. Én primær CTA per skjerm

Eksempel:

```text
[Start kontroll]
```

Sekundære handlinger:

```text
Vis detaljer
Erstatt fil
Ikke bruk i saken
```

### 2. Ikke bruk for mange badges

Maks 1–2 statusbadges i hovedkort.

Bra:

```text
Kontroll kreves
6 dokumenter må vurderes
```

Dårlig:

```text
OCR FAILED · SOURCE_COUNT=0 · READINESS_FALSE · REVIEW_PENDING · HASH_OK
```

### 3. Progressive disclosure

Tre nivåer:

```text
Nivå 1: status + neste handling
Nivå 2: dokumenter og årsak
Nivå 3: teknisk/audit
```

### 4. Spacing

Bruk luft. Ikke fyll alle paneler med kort.

Anbefaling:

```css
:root {
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-5: 24px;
  --space-6: 32px;
  --radius-card: 16px;
  --radius-button: 12px;
}
```

### 5. Typography

- H1: skjermens hovedjobb
- H2: område
- Body: forklaring
- Small: metadata

Ikke bruk små tekster for kritisk status.

### 6. Status pattern

Alle statuskort skal ha:

```text
status label
title
body
primary action
secondary details
```

### 7. Motion

- Subtil.
- Ikke animér readiness på en måte som gjør status vanskelig å lese.
- Respekter reduced motion.

### 8. Color

- Ikke bruk mange accent colors.
- Primærfarge kun for primærhandling.
- Warning/error skal ikke dominere hele skjermen med mindre faktisk blokkert feil.

### 9. Empty states

Empty state må alltid ha neste handling.

Eksempel:

```text
Ingen dokumenter ennå

Legg til dokumenter for å bygge kildegrunnlag før Saksrom åpnes.

[Legg til dokumenter]
```

### 10. Loading states

Loading copy skal være rolig:

```text
Saken klargjøres
Evida leser dokumenter og bygger sporbare kilder.
```

Ikke:

```text
Chunking vector index...
```
