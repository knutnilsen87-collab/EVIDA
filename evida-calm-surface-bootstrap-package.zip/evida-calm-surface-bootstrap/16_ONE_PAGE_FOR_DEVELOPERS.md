# 16 Énside for utviklere

## Bygg dette først

```text
ReadinessStatusCard
→ CalmSidebar routing
→ DocumentControlView
→ DocumentDecisionPanel copy
→ CaseRoomGate
→ Source summary/citation chips
```

## Ikke bygg dette nå

```text
Full redesign
Autonom AI
Figma integration
Cloud sync
Produksjonsdataflyt
Avansert analytics med sensitiv data
```

## Hard rules

```text
Saksrom uten kilder = ingen fri chat.
Dokument uten source_count = kan ikke godkjennes som kilde.
Bulk = alltid bekreftelse.
Teknisk info = Vis detaljer.
Hver skjerm = én primær CTA.
```

## Hovedcopy

```text
Kontroll kreves
6 dokumenter må vurderes før Saksrom kan åpnes.
[Start kontroll]
```

```text
Kontrollert, men ikke siterbar
Dokumentet er håndtert, men brukes ikke som AI-kilde i Saksrom.
```

```text
Saken er klar
Evida har bygget sporbare kilder fra dokumentene.
[Åpne Saksrom]
```

## Files

```text
src/App.tsx
src/components/Sidebar.tsx
src/components/CaseRoomView.tsx
src/components/SourcePanel.tsx
src/styles.css

src/features/readiness/caseReadiness.ts
src/components/readiness/ReadinessStatusCard.tsx

src/components/documents/DocumentControlView.tsx
src/components/documents/DocumentQueue.tsx
src/components/documents/DocumentPreviewPanel.tsx
src/components/documents/DocumentDecisionPanel.tsx
src/components/documents/BulkActionBar.tsx
```

## Done når

- Saksrom er låst med god forklaring.
- Dokumentkontroll er rask og trygg.
- Brukeren ser konsekvensen av hvert valg.
- Første Saksrom-svar bygger tillit med kilder.
- Build/test er grønn.
