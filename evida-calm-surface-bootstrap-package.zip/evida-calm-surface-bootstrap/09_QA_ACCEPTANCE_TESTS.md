# 09 QA acceptance tests

## A. Readiness og Saksrom

### A1 — Ny sak uten dokumenter

Gitt: ny sak uten dokumenter  
Når: bruker klikker Saksrom  
Forventet:

- [ ] Saksrom åpnes ikke som full chat.
- [ ] Bruker ser `Legg til dokumenter`.
- [ ] CTA er `Legg til dokumenter`.
- [ ] Chat input er skjult eller disabled.

### A2 — Import pågår

Gitt: dokumentimport pågår  
Når: bruker klikker Saksrom  
Forventet:

- [ ] Bruker blir på/rutes til klargjøringsstatus.
- [ ] Status sier `Saken klargjøres`.
- [ ] ETA vises bare hvis import er aktiv.
- [ ] CTA er ikke `Åpne Saksrom`.

### A3 — Kontroll gjenstår

Gitt: import er ferdig, men dokumenter trenger kontroll  
Når: bruker klikker Saksrom  
Forventet:

- [ ] Status sier `Kontroll kreves`.
- [ ] CTA er `Start kontroll`.
- [ ] Saksrom chat input er ikke tilgjengelig.
- [ ] Ingen teknisk `readiness false` vises.

### A4 — Ingen kilder

Gitt: dokumenter finnes, men `sourceObjectsCount === 0`  
Når: bruker forsøker Saksrom  
Forventet:

- [ ] Blocked state vises.
- [ ] Copy sier `Kildegrunnlag mangler`.
- [ ] CTA er `Åpne kontroll`.
- [ ] Ingen frie spørsmål kan sendes.

### A5 — Klar sak

Gitt: import ferdig, ingen uavklarte kontrollitems, minst ett source object  
Når: bruker klikker Saksrom  
Forventet:

- [ ] Saksrom åpnes.
- [ ] Kildeoppsummering vises.
- [ ] Input er tilgjengelig.
- [ ] Første svar viser kilder eller eksplisitt manglende kilde.

---

## B. Import og ETA

### B1 — Aktiv behandling

- [ ] Viser `Saken klargjøres`.
- [ ] Viser dokumenter x/y.
- [ ] Viser fase.
- [ ] Viser ETA bare mens aktiv.
- [ ] Lang dokumentliste er bak `Vis detaljer`.

### B2 — Ferdig import

- [ ] Ikke vis `ETA beregnes ...`.
- [ ] Ikke vis `Import pågår`.
- [ ] Fase er `Ferdig` eller skjult.
- [ ] Hvis kontroll trengs, vis `Kontroll kreves`.

### B3 — Import feilet

- [ ] Bruker ser rolig error state.
- [ ] CTA er `Åpne kontroll` eller `Prøv igjen`.
- [ ] Tekniske feildetaljer ligger bak `Vis detaljer`.

---

## C. Dokumentkontroll

### C1 — Layout

- [ ] Venstre kolonne er dokumentkø.
- [ ] Midtkolonne er preview.
- [ ] Høyre kolonne er beslutning.
- [ ] Ingen Windows Utforsker åpnes ved vanlig radklikk.

### C2 — Dokument med kilder

Forventet knapper:

- [ ] `Godkjenn som kilde`
- [ ] `Ikke bruk i saken`
- [ ] `Erstatt fil`

Krav:

- [ ] Helper forklarer at dokumentet kan brukes i Saksrom med kildehenvisning.

### C3 — Dokument uten lesbar tekst

Forventet knapper:

- [ ] `Kontrollert, men ikke siterbar`
- [ ] `Erstatt fil`
- [ ] `Ikke bruk i saken`

Krav:

- [ ] Det står tydelig at dokumentet ikke brukes som AI-kilde.

### C4 — Etter beslutning

- [ ] Dokument fjernes fra kontrollkø eller markeres resolved.
- [ ] Neste dokument velges automatisk.
- [ ] Readiness oppdateres.

### C5 — Empty state

Gitt: ingen dokumenter trenger kontroll  
Forventet:

- [ ] `Ingen dokumenter trenger kontroll`
- [ ] CTA `Åpne Saksrom`

---

## D. Bulk

### D1 — Velg flere dokumenter

- [ ] Sticky bulkbar vises.
- [ ] Antall valgte vises.
- [ ] `Fjern valg` fungerer.

### D2 — Bulk med ikke-siterbare dokumenter

Gitt: minst ett valgt dokument mangler source_count  
Forventet:

- [ ] `Godkjenn valgte som kilde` er disabled/skjult.
- [ ] Copy forklarer hvorfor.
- [ ] `Kontrollert, men ikke siterbar` er tilgjengelig.

### D3 — Bekreftelse

- [ ] Bekreftelsesdialog viser konsekvens.
- [ ] Bekreft/Avbryt fungerer.
- [ ] Escape lukker dialog.
- [ ] Handling audit-logges per dokument.

---

## E. Saksrom og kilder

### E1 — Source summary

- [ ] Viser antall godkjente kilder.
- [ ] Viser dokumenter som ikke brukes.
- [ ] `Vis kildegrunnlag` åpner kontroll/source view.

### E2 — Citation chips

- [ ] Kildechips er synlige på svar.
- [ ] Chips kan aktiveres med mus.
- [ ] Chips kan aktiveres med tastatur.
- [ ] `aria-label` beskriver dokument og side.
- [ ] Kildekort viser dokument, side og utdrag.

### E3 — Manglende kilde

Gitt: svar mangler kildegrunnlag  
Forventet:

- [ ] UI sier `Jeg kan ikke kildeverifisere dette med tilgjengelige dokumenter.`
- [ ] Ingen falske citations vises.

---

## F. Accessibility

- [ ] Tab-rekkefølge er logisk.
- [ ] Fokusmarkering er tydelig.
- [ ] Dokumentkø støtter pil opp/ned.
- [ ] Enter velger/aktiverer.
- [ ] Status/progress bruker `aria-live="polite"`.
- [ ] Ikke bruk farge alene for status.
- [ ] Reduced motion respekteres hvis animasjoner finnes.

---

## G. Build/test

Kjør:

```powershell
cd evida-core\desktop-tauri
npm.cmd run test
npm.cmd run build
```

Hvis release skal bygges:

```powershell
npm.cmd run tauri:build
```

Fra repo-roten ved release:

```powershell
powershell -ExecutionPolicy Bypass -File .\ops\New-EvidaRelease.ps1
powershell -ExecutionPolicy Bypass -File .\ops\Test-EvidaRelease.ps1
```
