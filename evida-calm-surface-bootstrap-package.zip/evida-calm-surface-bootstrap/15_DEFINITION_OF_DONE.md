# 15 Definition of Done

## Produkt

- [ ] Brukeren kan alltid se hva som skjer nå.
- [ ] Brukeren kan alltid se hva neste trygge handling er.
- [ ] Saksrom åpnes ikke som full arbeidsflate uten sporbare kilder.
- [ ] Låst Saksrom forklares som beskyttelse, ikke som teknisk feil.

## UX

- [ ] Hver skjerm har maks én primær CTA.
- [ ] Teknisk info ligger bak `Vis detaljer`.
- [ ] Dokumentkontroll er kø → preview → beslutning.
- [ ] Copy forklarer konsekvens av hver beslutning.
- [ ] Bulk forklarer konsekvens og krever bekreftelse.
- [ ] Første Saksrom-opplevelse viser kildeoppsummering.

## UI

- [ ] Sidebar er redusert og progressiv.
- [ ] Analysemoduler dominerer ikke før saken er klar.
- [ ] Importstatus er kompakt og stabil.
- [ ] Empty/loading/error states er rolige og handlingsnære.
- [ ] Premium-følelse: luft, tydelig hierarki, få badges, konsistent spacing.

## Kilde/tillit

- [ ] Dokument uten source objects kan ikke godkjennes som AI-kilde.
- [ ] `Kontrollert, men ikke siterbar` brukes tydelig.
- [ ] `Godkjenn som kilde` brukes bare når dokumentet faktisk kan brukes som kilde.
- [ ] Ingen falske citations.
- [ ] Manglende kildegrunnlag vises eksplisitt.

## Accessibility

- [ ] Dokumentkø er keyboard-friendly.
- [ ] Fokusmarkering er tydelig.
- [ ] Citation chips er buttons.
- [ ] `aria-live="polite"` brukes for status.
- [ ] Ikke bruk farge alene for status.
- [ ] Escape lukker modaler/popovers.

## Security/privacy

- [ ] Pre-alpha/testdata forklares før første import.
- [ ] Ingen dokumenttekst i logs.
- [ ] Ingen secrets eksponeres.
- [ ] Ekstern AI er av som default.
- [ ] Destruktive/risikable actions krever bekreftelse.

## QA

- [ ] `npm.cmd run test` kjørt eller dokumentert hvorfor ikke.
- [ ] `npm.cmd run build` kjørt eller dokumentert hvorfor ikke.
- [ ] Manual smoke fullført.
- [ ] Acceptance tests i `09_QA_ACCEPTANCE_TESTS.md` er gått gjennom.
- [ ] Release checklist oppdatert ved behov.
