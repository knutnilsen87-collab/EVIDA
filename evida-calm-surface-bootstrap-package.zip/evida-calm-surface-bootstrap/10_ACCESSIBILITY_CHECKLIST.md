# 10 Accessibility checklist

## Prinsipp

Tilgjengelighet er ikke sekundært her. Dokumentkontroll er allerede kognitivt tung. Dårlig keyboard/focus gjør den ubrukelig for power users, lavenergi-brukere og skjermleserbrukere.

## Dokumentkø

- [ ] Bruk semantisk liste eller listbox.
- [ ] Valgt dokument har `aria-selected`.
- [ ] Checkbox har tydelig label.
- [ ] Pil opp/ned flytter fokus/valg.
- [ ] Enter åpner/velger dokument.
- [ ] Space toggler checkbox når fokus er på checkbox.
- [ ] Fokusmarkering er synlig mot både lys og mørk bakgrunn.

## Preview

- [ ] PDF/bilde har tekstfallback hvis mulig.
- [ ] Unsupported preview har rolig forklaring.
- [ ] Preview-panelet har heading som sier hvilket dokument som vises.
- [ ] Ikke flytt fokus ukontrollert ved dokumentbytte.

## Decision panel

- [ ] Knappetekster er handlingsspesifikke.
- [ ] Hver knapp har helper text eller `aria-describedby`.
- [ ] Primærhandling kommer først.
- [ ] Destructive/exclusion actions er visuelt sekundære.
- [ ] Etter beslutning flyttes fokus til neste dokument eller status.

## Bulk

- [ ] Bulkbar annonserer antall valgte.
- [ ] Bekreftelsesdialog bruker focus trap.
- [ ] Escape lukker dialog.
- [ ] Dialogtittel sier konsekvens.
- [ ] Bekreft-knapp er ikke farlig generisk `OK`.

## Status/progress

- [ ] Bruk `aria-live="polite"`.
- [ ] Ikke annonser hvert prosentpoeng.
- [ ] Annonser bare meningsfulle faser.
- [ ] ETA-endringer bør ikke spamme skjermleser.

## Citation chips

- [ ] Chips er `<button>`.
- [ ] `aria-label` inkluderer dokument og side.
- [ ] Enter/Space åpner kildekort.
- [ ] Kildekort kan lukkes med Escape.
- [ ] Fokus returnerer til chip etter lukking.

## Motion

- [ ] Respekter `prefers-reduced-motion`.
- [ ] Bruk korte, rolige transitions.
- [ ] Ikke animer kritiske statusendringer på en måte som skjuler innhold.

## Kontrast og status

- [ ] Ikke bruk bare farge for `klar`, `kontroll kreves`, `feilet`.
- [ ] Bruk tekst + ikon + statuslabel.
- [ ] Disabled states må fortsatt være lesbare.
