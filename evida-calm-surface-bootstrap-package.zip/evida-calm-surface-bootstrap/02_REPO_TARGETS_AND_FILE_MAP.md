# 02 Repo-targets og file map

Dette er de mest sannsynlige filene utviklerne må endre i `CasePilot`.

## Frontend core

```text
evida-core/desktop-tauri/src/App.tsx
evida-core/desktop-tauri/src/types.ts
evida-core/desktop-tauri/src/styles.css
```

### `App.tsx`

Eier mye av orkestreringen:

- aktiv sak
- aktiv visning
- onboarding/import state
- importkø
- dokumentliste
- source objects
- readiness-ish logikk
- routing til Saksrom, kontroll og dokumenter

Prioritet:

1. trekk readiness-beregning ut av inline-logikk
2. ikke rout automatisk til full Saksrom hvis `sourceCount <= 0`
3. bruk én `getNextUserAction(readiness)`-kontrakt
4. vis `ReadinessStatusCard` konsekvent på relevante flater

## Sidebar

```text
evida-core/desktop-tauri/src/components/Sidebar.tsx
```

Dagens risiko:

- mange arbeidsrom vises direkte
- låste elementer kan fortsatt skape støy
- analysemoduler vises før brukeren trenger dem

Mål:

```text
Før dokumenter:
- Sak
- Dokumenter
- Saksrom 🔒

Ved kontroll:
- Sak
- Dokumenter
- Kontroll
- Saksrom 🔒

Når klar:
- Sak
- Saksrom
- Dokumenter
- Kontroll
- Analyse
- Eksport
```

Analyseundermoduler bør være bak én `Analyse`-inngang, ikke 6 separate sidebar-elementer i førsteflyten.

## Saksrom

```text
evida-core/desktop-tauri/src/components/CaseRoomView.tsx
```

Mål:

- ikke tillat frie spørsmål uten kilder
- skill `blocked`, `preview`, `ready`
- vis kildeoppsummering før/ved første svar
- behold kilder, usikkerhet og neste steg, men hold default view rolig
- citation chips må være tastaturvennlige

Anbefalt gating:

```ts
const caseRoomMode =
  !selectedCase?.id ? "no_case" :
  !hasDocuments ? "needs_documents" :
  !hasSources ? "needs_sources" :
  isIncomplete ? "preview" :
  "ready";
```

## Source/Control

```text
evida-core/desktop-tauri/src/components/SourcePanel.tsx
```

Dagens risiko:

- nyttig, men kan være for synlig
- blander kontroll, audit, coverage og deviations i hovedflaten

Mål:

- gjør dette til `Control`/drawer/secondary panel
- på hovedflate: kort status og `Se kontroll`
- teknisk info bak `Vis detaljer`

## Nye komponenter anbefalt

```text
src/components/readiness/ReadinessStatusCard.tsx
src/features/readiness/caseReadiness.ts
src/features/readiness/nextAction.ts

src/components/documents/DocumentControlView.tsx
src/components/documents/DocumentQueue.tsx
src/components/documents/DocumentPreviewPanel.tsx
src/components/documents/DocumentDecisionPanel.tsx
src/components/documents/BulkActionBar.tsx

src/components/case-room/CaseRoomGate.tsx
src/components/case-room/CaseRoomSourceSummary.tsx
src/components/case-room/CitationChip.tsx

src/components/privacy/PrivacyPreAlphaNotice.tsx
```

## Backend/Rust sannsynlige targets

```text
evida-core/desktop-tauri/src-tauri/src/commands.rs
evida-core/desktop-tauri/src-tauri/src/db.rs
evida-core/desktop-tauri/src-tauri/src/ingestion.rs
evida-core/desktop-tauri/src-tauri/src/ingestion_core.rs
evida-core/desktop-tauri/src-tauri/src/audit.rs
```

Bruk backend-endringer kun der de trengs for:

- persistent manual review state
- audit per manual action
- source eligibility
- citation validation
- replacement/exclusion handling

## Test targets

```text
evida-core/desktop-tauri/scripts/
docs/ACCEPTANCE_SMOKE_TEST.md
docs/PILOT_EVALUATION_PLAN.md
docs/RELEASE_CHECKLIST.md
```

Nye tester bør dekke:

- Saksrom locked states
- import completion routing
- ETA-regler
- dokumentkontroll decisions
- bulk-safety
- citation chips
- accessibility basics
