# Installér pakken i repoet

Fra repo-roten:

```powershell
mkdir docs\evida-calm-surface-bootstrap
```

Kopier alle filene fra denne pakken inn i:

```text
docs/evida-calm-surface-bootstrap/
```

Start branch:

```powershell
git checkout -b calm-surface-readiness-document-control
```

Gi Codex/coding agent denne filen først:

```text
docs/evida-calm-surface-bootstrap/08_CODEX_PROMPTS.md
```

Anbefalt første prompt:

```text
Bruk Master prompt fra 08_CODEX_PROMPTS.md, men implementer først bare Prompt 1 — Readiness only.
```
