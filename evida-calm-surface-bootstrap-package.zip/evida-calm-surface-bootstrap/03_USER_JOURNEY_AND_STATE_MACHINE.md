# 03 User journey og state machine

## Ideell brukerreise

```mermaid
flowchart TD
  A["Start Evida"] --> B["Opprett eller velg sak"]
  B --> C{"Har dokumenter?"}
  C -- "Nei" --> D["Legg til dokumenter"]
  C -- "Ja" --> E["Klargjør dokumenter"]
  D --> E
  E --> F{"Import ferdig?"}
  F -- "Nei" --> E
  F -- "Ja" --> G{"Kontroll kreves?"}
  G -- "Ja" --> H["Dokumentkontroll"]
  H --> I{"Alle avvik håndtert?"}
  I -- "Nei" --> H
  I -- "Ja" --> J{"Har sporbare kilder?"}
  G -- "Nei" --> J
  J -- "Nei" --> K["Kildegrunnlag mangler: kontroller/erstatt dokumenter"]
  J -- "Ja" --> L["Saksrom åpnes"]
  L --> M["Kildebasert spørsmål/svar"]
  M --> N["Analyse / utkast / eksport"]
```

## Readiness-state

Bruk én state-kontrakt på tvers av UI.

```ts
export type CaseReadinessStatus =
  | "no_case"
  | "no_documents"
  | "importing"
  | "needs_control"
  | "needs_sources"
  | "ready"
  | "error";

export type NextActionKey =
  | "create_case"
  | "add_documents"
  | "show_import_status"
  | "start_control"
  | "replace_or_review_documents"
  | "open_case_room"
  | "show_error_details";

export interface CaseReadiness {
  status: CaseReadinessStatus;
  isReadyForCaseRoom: boolean;
  canAskInCaseRoom: boolean;
  title: string;
  body: string;
  missing: string[];
  nextAction: {
    key: NextActionKey;
    label: string;
    targetView: ViewKey;
  };
  counts: {
    totalDocuments: number;
    readyDocuments: number;
    unresolvedControlDocuments: number;
    sourceObjects: number;
    pendingOcrPages: number;
    totalPages: number;
    processedPages: number;
  };
}
```

## Statusregler

### `no_case`

```text
Tittel: Ingen sak valgt
Body: Opprett eller velg en sak før du legger til dokumenter.
CTA: Opprett ny sak
```

### `no_documents`

```text
Tittel: Legg til dokumenter
Body: Saksrom åpnes når Evida har bygget sporbare kilder fra dokumentene.
CTA: Legg til dokumenter
```

### `importing`

```text
Tittel: Saken klargjøres
Body: Evida leser dokumenter og bygger sporbare kilder.
CTA: Vis behandlingsstatus
```

### `needs_control`

```text
Tittel: Kontroll kreves
Body: {n} dokumenter må vurderes før Saksrom kan åpnes.
CTA: Start kontroll
```

### `needs_sources`

```text
Tittel: Kildegrunnlag mangler
Body: Dokumenter er importert, men Evida har ingen sporbare kilder ennå.
CTA: Åpne kontroll
```

### `ready`

```text
Tittel: Saken er klar
Body: Evida har bygget sporbare kilder fra dokumentene.
CTA: Åpne Saksrom
```

## Routing-regler

Når bruker klikker låst Saksrom:

```ts
function routeLockedCaseRoom(readiness: CaseReadiness): ViewKey {
  switch (readiness.status) {
    case "no_case":
    case "no_documents":
      return "documents";
    case "importing":
      return "documents"; // import status area
    case "needs_control":
    case "needs_sources":
      return "control";
    case "ready":
      return "caseRoom";
    case "error":
      return "control";
  }
}
```

## Saksrom-modus

```ts
type CaseRoomMode = "blocked" | "preview" | "ready";

function getCaseRoomMode(readiness: CaseReadiness): CaseRoomMode {
  if (!readiness.counts.sourceObjects) return "blocked";
  if (!readiness.isReadyForCaseRoom) return "preview";
  return "ready";
}
```

### `blocked`

- vis forklaring
- ingen chat input
- CTA til kontroll/dokumenter

### `preview`

- vis kildegrunnlag og hva som mangler
- vurder om chat input skal være begrenset
- merk alt som ufullstendig

### `ready`

- full Saksrom
- inline kilder
- kildeoppsummering
- usikkerhet og mangler bak details
