# Evida Calm Surface Bootstrap Package

Dato: 2026-05-18  
Målgruppe: utviklere, produkteier, UX/UI, QA og Codex/coding agent  
Repo: `knutnilsen87-collab/CasePilot`  
Status: implementeringspakke, ikke en ferdig patch

## Formål

Denne pakken gjør det enklest mulig å implementere den nye Evida-flyten vi har kommet frem til:

```text
Ny sak
→ Legg til dokumenter
→ Klargjør dokumenter
→ Kontrollér avvik
→ Saksrom åpnes når kildegrunnlaget er klart
→ Analyse / utkast / eksport
```

Kjernen er:

```text
Ikke vis mer systemlogikk enn brukeren trenger for å ta neste trygge handling.
```

## Viktigste beslutning

**Saksrom skal ikke føles som en generell chat som brukeren kan bruke når som helst.  
Saksrom skal føles som et trygt arbeidsrom som åpnes når dokumentgrunnlaget er klart.**

## P1-arbeidet

1. `ReadinessStatusCard`
   - Én tydelig status: hva skjer nå, hva mangler, neste handling.
2. `DocumentControlView`
   - Kø → preview → beslutning → neste dokument.
3. `DocumentDecisionPanel`
   - Skiller tydelig mellom `Godkjenn som kilde`, `Kontrollert, men ikke siterbar`, og `Ikke bruk i saken`.
4. `CaseRoomGate`
   - Saksrom låses eller settes i preview/blocked state når kildegrunnlaget mangler.
5. `CaseRoomSourceSummary`
   - Første Saksrom-opplevelse viser kildeoppsummering og inline citation chips.
6. `PrivacyPreAlphaNotice`
   - Rolig forklaring før første import: lokal behandling, testdata, begrensninger.

## Slik bruker utviklerne pakken

1. Pakk ut denne mappen i repoet, for eksempel:

```text
docs/evida-calm-surface-bootstrap/
```

2. Les i denne rekkefølgen:

```text
00_START_HERE.md
01_PRODUCT_RULES.md
02_REPO_TARGETS_AND_FILE_MAP.md
03_USER_JOURNEY_AND_STATE_MACHINE.md
04_COMPONENT_SPECS.md
05_COPY_DECK_NB.md
06_TYPES_AND_READINESS_CONTRACT.md
07_IMPLEMENTATION_TASKS.md
08_CODEX_PROMPTS.md
09_QA_ACCEPTANCE_TESTS.md
```

3. Start med en smal branch:

```powershell
git checkout -b calm-surface-readiness-document-control
```

4. Implementer P1 i denne rekkefølgen:

```text
readiness contract
→ readiness status card
→ sidebar gating
→ import routing
→ document control queue
→ document decision copy
→ case room gate
→ source summary/citations
→ QA tests
```

## Ikke gjør dette i samme sprint

- Ikke bygg full autonom AI.
- Ikke redesign hele appen visuelt.
- Ikke flytt all dataarkitektur før UI-kontraktene er klare.
- Ikke åpne Saksrom med frie spørsmål hvis saken ikke har sporbare kilder.
- Ikke bruk tvetydige knapper som bare `Godkjenn`, `Fortsett`, `OK`.

## Definition of Done

Implementeringen er ikke ferdig før:

- brukeren alltid forstår hvorfor Saksrom er låst
- hver skjerm har én tydelig primærhandling
- dokumentkontroll kan gjennomføres uten tekniske begreper
- dokument uten kildegrunnlag ikke kan bli AI-siterbar kilde
- bulk krever bekreftelse og viser konsekvens
- første Saksrom-svar viser kilder eller sier eksplisitt at kilde mangler
- teknisk informasjon ligger bak `Vis detaljer`
- tastaturflyt, fokus og `aria-live` er håndtert
