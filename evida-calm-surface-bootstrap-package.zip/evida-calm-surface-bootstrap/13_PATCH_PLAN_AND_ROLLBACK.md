# 13 Patch plan og rollback

## Branch

```powershell
git checkout -b calm-surface-readiness-document-control
```

## Foreslått commit-rekkefølge

### Commit 1 — Readiness contract

```text
feat(readiness): add case readiness contract and next action mapping
```

Innhold:

- `caseReadiness.ts`
- unit tests hvis mulig
- ingen UI-storendring

Rollback:

```powershell
git revert <commit>
```

### Commit 2 — ReadinessStatusCard

```text
feat(ui): show calm readiness status card across case flow
```

Innhold:

- component
- minimal CSS
- wiring i App

### Commit 3 — Sidebar gating

```text
feat(nav): simplify sidebar and route locked case room clicks
```

Innhold:

- Sidebar logic
- hidden/merged analysis items
- locked target routing

### Commit 4 — Import routing and status

```text
fix(import): route incomplete imports to control instead of full case room
```

Innhold:

- import completion routing
- ETA cleanup
- compact status

### Commit 5 — Document control queue

```text
feat(documents): add three-column document control workflow
```

Innhold:

- queue
- preview
- decision panel
- resolved flow

### Commit 6 — Bulk safety

```text
feat(documents): add safe bulk decisions with confirmation
```

Innhold:

- bulkbar
- disabled approve as source when unsafe
- audit hooks

### Commit 7 — CaseRoom gate and source summary

```text
feat(case-room): gate questions by source readiness and show source summary
```

Innhold:

- blocked/preview/ready
- citation chip improvements

### Commit 8 — QA

```text
test: add calm surface readiness and document control checks
```

Innhold:

- tests
- docs update
- smoke checklist

## Risk labels

| Area | Risk | Note |
|---|---|---|
| Readiness contract | Medium | Kan påvirke navigation |
| Sidebar | Low | Mest UI/routing |
| Import routing | Medium | Kan endre first-value flow |
| DocumentControlView | Medium/High | Ny review workflow |
| Bulk | Medium | Krever audit og safety |
| CaseRoomGate | Medium | Endrer hva bruker kan spørre om |
| Copy/CSS | Low | Visuell/tekstlig |

## Rollback strategy

Hvis noe går feil:

1. Rollback siste commit.
2. Behold readiness contract hvis den er stabil.
3. Deaktiver nye komponenter bak feature flag hvis nødvendig.

Feature flag forslag:

```ts
const ENABLE_CALM_SURFACE = true;
const ENABLE_NEW_DOCUMENT_CONTROL = true;
const ENABLE_CASE_ROOM_GATE = true;
```

## Pre-merge checklist

- [ ] `npm.cmd run test`
- [ ] `npm.cmd run build`
- [ ] Manual smoke: ny sak → dokumenter → kontroll → Saksrom
- [ ] Manual smoke: dokument uten kilder åpner ikke full Saksrom
- [ ] Manual smoke: bulk med ikke-siterbare dokumenter kan ikke godkjennes som kilder
- [ ] Copy matcher copydeck
- [ ] Ingen secrets eller sensitiv tekst i logs
