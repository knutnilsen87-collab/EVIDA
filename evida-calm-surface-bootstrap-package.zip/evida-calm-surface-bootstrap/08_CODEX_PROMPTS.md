# 08 Codex prompts

## Master prompt

```text
Du er senior full-stack Tauri/React/Rust-utvikler for Evida i repoet `knutnilsen87-collab/CasePilot`.

Mål:
Implementer Calm Surface-flyten for Evida slik at appen blir ren, handlingsstyrt og trygg for juridiske brukere.

Kjerneprinsipp:
Ikke vis mer systemlogikk enn brukeren trenger for å ta neste trygge handling.

Produktregler:
1. Saksrom skal ikke åpne som full arbeidsflate før saken har sporbare kilder og uavklarte dokumenter er håndtert.
2. Brukeren skal alltid se hvorfor Saksrom er låst og hva neste handling er.
3. Dokumentkontroll skal være kø → preview → beslutning → neste dokument.
4. Dokumentbeslutninger må skille tydelig mellom:
   - Godkjenn som kilde
   - Kontrollert, men ikke siterbar
   - Ikke bruk i saken
5. Dokument uten source objects kan ikke bulk-godkjennes som kilde.
6. Importstatus skal være kompakt, stabil og uten ETA etter ferdig import.
7. Teknisk informasjon skal ligge bak `Vis detaljer`.
8. Første Saksrom-opplevelse skal vise kildeoppsummering og inline citation chips.
9. Pre-alpha/privacy skal forklares rolig før første import.
10. Ikke gjør destruktive endringer og ikke rør secrets.

Les disse dokumentene først:
- docs/evida-calm-surface-bootstrap/00_START_HERE.md
- docs/evida-calm-surface-bootstrap/01_PRODUCT_RULES.md
- docs/evida-calm-surface-bootstrap/03_USER_JOURNEY_AND_STATE_MACHINE.md
- docs/evida-calm-surface-bootstrap/04_COMPONENT_SPECS.md
- docs/evida-calm-surface-bootstrap/05_COPY_DECK_NB.md
- docs/evida-calm-surface-bootstrap/06_TYPES_AND_READINESS_CONTRACT.md
- docs/evida-calm-surface-bootstrap/07_IMPLEMENTATION_TASKS.md
- docs/evida-calm-surface-bootstrap/09_QA_ACCEPTANCE_TESTS.md

Før du endrer kode:
1. Kartlegg relevante filer.
2. Lag en kort patchplan.
3. Hold endringene små og testbare.

Implementer i denne rekkefølgen:
1. `src/features/readiness/caseReadiness.ts`
2. `ReadinessStatusCard`
3. Sidebar gating/routing
4. Import completion routing
5. DocumentControlView + DecisionPanel + BulkActionBar
6. CaseRoomGate
7. CaseRoomSourceSummary + CitationChip
8. PrivacyPreAlphaNotice
9. Tests og acceptance smoke docs

Acceptance:
- `npm.cmd run test` skal passere hvis testscript finnes.
- `npm.cmd run build` skal passere.
- Saksrom er låst når:
  - ingen dokumenter
  - import pågår
  - kontroll gjenstår
  - sourceObjectsCount er 0
- Saksrom åpnes når:
  - import er ferdig
  - uavklarte review items er 0
  - minst ett source object finnes
- Dokumentkontroll viser 3 kolonner.
- Preview åpnes i appen.
- Bulk krever bekreftelse og audit.
- Copy bruker ordene fra copydeck.
- Ingen tekniske debug-detaljer vises i hovedflaten.
- Alle nye states har loading/empty/error copy.
- Tastatur/fokus er ivaretatt.

Ikke gjør:
- ikke bygg full redesign
- ikke endre unrelated business logic
- ikke rør `.env`, keys, credentials eller produksjonsconfig
- ikke legg inn ekstern AI som default
- ikke fjern audit/sikkerhetsmekanismer
- ikke push til Git

Lever:
1. Kort oppsummering
2. Liste over endrede filer
3. Risiko
4. Tester kjørt
5. Eventuelle resterende TODOs
```

## Prompt 1 — Readiness only

```text
Implementer kun readiness contract og ReadinessStatusCard.

Scope:
- src/features/readiness/caseReadiness.ts
- src/components/readiness/ReadinessStatusCard.tsx
- nødvendig wiring i App.tsx
- minimal CSS

Ikke bygg DocumentControlView ennå.

Mål:
Brukeren skal alltid se status, hva som mangler og neste handling.
Saksrom skal ikke være full tilgjengelig uten kilder.

Bruk copy fra 05_COPY_DECK_NB.md.
```

## Prompt 2 — Sidebar and routing

```text
Implementer CalmSidebar gating.

Scope:
- src/components/Sidebar.tsx
- App.tsx navigation handlers
- readiness nextAction routing

Mål:
Sidebar skal vise færre valg i første flyt.
Klikk på låst Saksrom skal rute til riktig neste steg.
Analyseundermoduler skal ikke dominere før saken er klar.
```

## Prompt 3 — Document control

```text
Implementer DocumentControlView med 3 kolonner:
venstre kø, midten preview, høyre beslutning.

Bygg:
- DocumentControlView
- DocumentQueue
- DocumentPreviewPanel
- DocumentDecisionPanel
- BulkActionBar

Krav:
- ikke åpne Windows Utforsker som default
- rader har kort status
- beslutningscopy skiller siterbar/kontrollert/utelatt
- bulk krever bekreftelse
- ikke bulk-godkjenn som kilde hvis source_count mangler
```

## Prompt 4 — CaseRoom trust

```text
Implementer CaseRoomGate, CaseRoomSourceSummary og CitationChip.

Krav:
- ingen fri chat uten kilder
- blocked state med CTA til Kontroll
- ready state med kildeoppsummering
- citation chips er keyboard-friendly buttons
- manglende kildegrunnlag vises eksplisitt
```

## Prompt 5 — QA hardening

```text
Legg til/oppdater tester og smoke checklist for Calm Surface-flyten.

Må dekke:
- locked Saksrom uten dokumenter
- locked Saksrom under import
- kontroll kreves
- kildegrunnlag mangler
- klar sak åpner Saksrom
- ETA-regler
- dokumentbeslutningscopy
- bulk safety
- citation chips
- keyboard/focus basics
```
