# 00 Start her

## Én setning

Evida skal være en rolig juridisk dokumentklargjøringsflate der brukeren alltid vet hva som skjer, hva som mangler og hva neste trygge handling er.

## Bakgrunn

BUX-simuleringen peker på at den største friksjonen ikke er mangel på funksjoner, men kognitiv risiko. Brukeren må forstå for mange tilstander samtidig:

```text
import
readiness
kontroll
kildegrunnlag
siterbarhet
låst Saksrom
```

Største risikoområde er Dokumentkontroll. Brukeren kan misforstå forskjellen mellom:

```text
kontrollert
godkjent som kilde
kan brukes av AI
Saksrom er klart
```

## Produktmål for denne pakken

Reduser kognitiv risiko i første komplette saksflyt.

Brukeren skal trygt kunne:

1. opprette sak
2. legge til dokumenter
3. forstå readiness
4. kontrollere avvik
5. åpne Saksrom
6. stole på kildebaserte svar

uten å måtte forstå OCR, source objects, audit events, internal readiness flags eller coverage.

## Designprinsipp

```text
Clean on top. Powerful underneath.
```

På overflaten:

```text
Hva skjer nå?
Hva mangler?
Hva skal jeg gjøre?
Hva blir konsekvensen?
Kan jeg stole på svaret?
```

Under panseret:

```text
OCR
hash
source objects
audit events
coverage
manual review state
citation validation
```

## Første implementeringsmål

Ikke start med alt. Start med dette:

```text
UX-001 ReadinessStatusCard
UX-002 CalmSidebar gating
UX-003 ImportCompletionRouting
UX-004 DocumentControlView
UX-005 DocumentDecisionPanel copy
UX-006 CaseRoomGate
UX-007 FirstAnswerSourceSummary
```

Når disse er på plass, vil appen føles mye roligere uten at kraften fjernes.
