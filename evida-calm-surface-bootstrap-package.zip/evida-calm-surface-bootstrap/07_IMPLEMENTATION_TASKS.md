# 07 Implementeringstasks

## UX-001 — ReadinessStatusCard

Priority: P1  
Risk: Low/Medium  
Files:

```text
src/features/readiness/caseReadiness.ts
src/components/readiness/ReadinessStatusCard.tsx
src/App.tsx
src/styles.css
```

### Goal

Brukeren skal alltid se hvorfor Saksrom er låst/åpent og hva neste steg er.

### Acceptance criteria

- [ ] Vises på Saksoversikt, Dokumenter/import og Kontroll.
- [ ] Har én primær CTA.
- [ ] Bruker copy fra `05_COPY_DECK_NB.md`.
- [ ] Viser ikke tekniske labels i default state.
- [ ] `Vis detaljer` er sekundær.

---

## UX-002 — CalmSidebar gating

Priority: P1  
Risk: Low  
Files:

```text
src/components/Sidebar.tsx
src/App.tsx
```

### Goal

Redusere navigasjonsstøy og rute låste valg til riktig neste steg.

### Acceptance criteria

- [ ] Sidebar viser maks 5–6 primære innganger i førsteflyten.
- [ ] Analyseundermoduler skjules bak `Analyse` eller vises bare etter analyse.
- [ ] Klikk på låst Saksrom ruter til `readiness.nextAction.targetView`.
- [ ] Locked copy er brukerorientert, ikke teknisk.

---

## UX-003 — ImportCompletionRouting

Priority: P1  
Risk: Medium  
Files:

```text
src/App.tsx
src/features/readiness/caseReadiness.ts
```

### Goal

Ikke send bruker automatisk til full Saksrom hvis det ikke finnes sporbare kilder.

### Rule

```ts
if (sourceCount > 0 && unresolvedControlDocuments === 0) {
  setActiveView("caseRoom");
} else {
  setActiveView("control");
}
```

### Acceptance criteria

- [ ] `sourceCount === 0` åpner ikke full Saksrom.
- [ ] bruker sendes til Kontroll med forklaring.
- [ ] Saksrom composer er disabled/hidden uten kilder.

---

## UX-004 — ImportStatusCard

Priority: P1  
Risk: Low  
Files:

```text
src/components/documents/ImportStatusCard.tsx
src/App.tsx
src/styles.css
```

### Goal

Import skal føles stabil og rolig.

### Acceptance criteria

- [ ] Viser dokumenter, sider, kilder, fase og ETA.
- [ ] ETA vises bare mens import er aktiv.
- [ ] Ikke vis `ETA beregnes ...` ved 100 %.
- [ ] Lang dokumentliste bak `Vis detaljer`.

---

## UX-005 — DocumentControlView 3-kolonne

Priority: P1  
Risk: Medium/High  
Files:

```text
src/components/documents/DocumentControlView.tsx
src/components/documents/DocumentQueue.tsx
src/components/documents/DocumentPreviewPanel.tsx
src/components/documents/DocumentDecisionPanel.tsx
src/components/documents/BulkActionBar.tsx
src/App.tsx
```

### Goal

Gjør Dokumentkontroll til produksjonslinje: dokument → preview → beslutning → neste dokument.

### Acceptance criteria

- [ ] Venstre kolonne: kort dokumentkø.
- [ ] Midt: in-app preview.
- [ ] Høyre: beslutning.
- [ ] Etter beslutning fjernes dokument fra kø eller flyttes til resolved state.
- [ ] Neste dokument velges automatisk.
- [ ] Ingen Windows Utforsker åpnes som default.

---

## UX-006 — DocumentDecisionPanel copy and rules

Priority: P1  
Risk: Medium  
Files:

```text
src/components/documents/DocumentDecisionPanel.tsx
src/features/documents/documentBasis.ts
```

### Goal

Fjerne tvetydighet rundt `kontrollert`, `siterbar` og `AI-kilde`.

### Acceptance criteria

- [ ] `Godkjenn som kilde` vises bare når dokumentet kan bli kilde.
- [ ] `Kontrollert, men ikke siterbar` brukes for dokument uten lesbar tekst.
- [ ] `Ikke bruk i saken` forklarer at dokumentet holdes utenfor analyse og Saksrom.
- [ ] Ingen primærknapp heter bare `Godkjenn`.

---

## UX-007 — BulkActionBar safety

Priority: P1/P2  
Risk: Medium  
Files:

```text
src/components/documents/BulkActionBar.tsx
src/components/documents/DocumentControlView.tsx
src-tauri/src/audit.rs
```

### Goal

Bulk skal spare tid uten å føles risikabelt.

### Acceptance criteria

- [ ] Viser antall valgte.
- [ ] Krever bekreftelse.
- [ ] Forklarer konsekvens.
- [ ] Deaktiverer `Godkjenn valgte som kilde` hvis noen valgte mangler source objects.
- [ ] Audit-logges per dokument.

---

## UX-008 — CaseRoomGate

Priority: P1  
Risk: Medium  
Files:

```text
src/components/case-room/CaseRoomGate.tsx
src/components/CaseRoomView.tsx
src/App.tsx
```

### Goal

Saksrom skal ikke svare fritt uten kilder.

### Acceptance criteria

- [ ] `blocked` state uten chat input når kilder mangler.
- [ ] `preview` state hvis kildegrunnlag er ufullstendig.
- [ ] `ready` state gir full Saksrom.
- [ ] CTA til Kontroll ved manglende grunnlag.

---

## UX-009 — FirstAnswerSourceSummary and CitationChip

Priority: P1  
Risk: Medium  
Files:

```text
src/components/case-room/CaseRoomSourceSummary.tsx
src/components/case-room/CitationChip.tsx
src/components/CaseRoomView.tsx
```

### Goal

Bygg tillit ved første Saksrom-opplevelse.

### Acceptance criteria

- [ ] Viser antall godkjente kilder.
- [ ] Viser antall ikke-siterbare/utelatte dokumenter.
- [ ] Alle kilder vises med keyboard-friendly chips.
- [ ] Manglende kilde vises eksplisitt.

---

## UX-010 — PrivacyPreAlphaNotice

Priority: P1  
Risk: Low  
Files:

```text
src/components/privacy/PrivacyPreAlphaNotice.tsx
src/App.tsx
```

### Goal

Redusere stopp før dokumentimport.

### Acceptance criteria

- [ ] Vises før første import.
- [ ] Sier lokal behandling.
- [ ] Sier testdata/evaluation build.
- [ ] Ikke skremmende modal.
- [ ] Kan lukkes/forstås uten å blokkere unødvendig.

---

## UX-011 — Accessibility pass

Priority: P1/P2  
Risk: Medium  
Files:

```text
src/components/documents/*
src/components/case-room/*
src/styles.css
```

### Acceptance criteria

- [ ] Dokumentkø kan brukes med tastatur.
- [ ] Fokusmarkering er tydelig.
- [ ] Status bruker `aria-live="polite"`.
- [ ] Citation chips er buttons med `aria-label`.
- [ ] Bulk confirmation kan lukkes med Escape.
- [ ] Ikke bruk farge alene for status.

---

## UX-012 — QA and regression tests

Priority: P1  
Risk: Low/Medium  
Files:

```text
scripts/
docs/ACCEPTANCE_SMOKE_TEST.md
docs/RELEASE_CHECKLIST.md
```

### Acceptance criteria

- [ ] Saksrom locked states testet.
- [ ] Import/ETA-regler testet.
- [ ] Document decisions testet.
- [ ] Bulk safety testet.
- [ ] First answer source summary testet.
