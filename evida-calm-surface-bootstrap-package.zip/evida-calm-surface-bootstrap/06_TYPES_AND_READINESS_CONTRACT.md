# 06 Types og readiness contract

Dette er en anbefalt TypeScript-kontrakt. Den kan tilpasses eksisterende `types.ts`.

## `caseReadiness.ts`

```ts
import type { CaseSummary, DocumentSummary, SourceObjectSummary, ViewKey } from "../../types";

export type CaseReadinessStatus =
  | "no_case"
  | "no_documents"
  | "importing"
  | "needs_control"
  | "needs_sources"
  | "ready"
  | "error";

export type NextActionKey =
  | "create_case"
  | "add_documents"
  | "show_import_status"
  | "start_control"
  | "replace_or_review_documents"
  | "open_case_room"
  | "show_error_details";

export interface CaseReadiness {
  status: CaseReadinessStatus;
  isReadyForCaseRoom: boolean;
  canAskInCaseRoom: boolean;
  title: string;
  body: string;
  missing: string[];
  nextAction: {
    key: NextActionKey;
    label: string;
    targetView: ViewKey;
  };
  counts: {
    totalDocuments: number;
    readyDocuments: number;
    unresolvedControlDocuments: number;
    sourceObjects: number;
    pendingOcrPages: number;
    totalPages: number;
    processedPages: number;
  };
}

export function getDocumentNeedsControl(document: DocumentSummary): boolean {
  const noSources = (document.source_count || 0) === 0;
  const pendingOcr = (document.pending_ocr_page_count || 0) > 0;
  const problematicOcr = [
    "needs_ocr",
    "partial_needs_ocr",
    "failed",
    "empty",
    "unsupported_file_type",
  ].includes(document.ocr_status);

  // TODO: replace with persistent manual review status when available.
  const manuallyResolved = [
    "reviewed_not_citable",
    "excluded",
    "duplicate_skipped",
    "failed_excluded",
    "unsupported_excluded",
  ].includes((document as any).review_status);

  return !manuallyResolved && (problematicOcr || pendingOcr || noSources);
}

export function getCaseReadiness(input: {
  selectedCase?: CaseSummary;
  documents: DocumentSummary[];
  sources: SourceObjectSummary[];
  isImporting: boolean;
}): CaseReadiness {
  const { selectedCase, documents, sources, isImporting } = input;

  const totalDocuments = documents.length;
  const sourceObjects = sources.length;
  const totalPages = documents.reduce((sum, doc) => sum + (doc.page_count || 0), 0);
  const processedPages = documents.reduce((sum, doc) => sum + (doc.analyzed_page_count || 0), 0);
  const pendingOcrPages = documents.reduce((sum, doc) => sum + (doc.pending_ocr_page_count || 0), 0);
  const unresolvedControlDocuments = documents.filter(getDocumentNeedsControl).length;
  const readyDocuments = documents.filter((doc) => (doc.source_count || 0) > 0).length;

  if (!selectedCase?.id) {
    return {
      status: "no_case",
      isReadyForCaseRoom: false,
      canAskInCaseRoom: false,
      title: "Ingen sak valgt",
      body: "Opprett eller velg en sak før du legger til dokumenter.",
      missing: ["Sak mangler"],
      nextAction: { key: "create_case", label: "Opprett ny sak", targetView: "overview" },
      counts: { totalDocuments, readyDocuments, unresolvedControlDocuments, sourceObjects, pendingOcrPages, totalPages, processedPages },
    };
  }

  if (totalDocuments === 0) {
    return {
      status: "no_documents",
      isReadyForCaseRoom: false,
      canAskInCaseRoom: false,
      title: "Legg til dokumenter",
      body: "Saksrom åpnes når Evida har bygget sporbare kilder fra dokumentene.",
      missing: ["Ingen dokumenter er lagt til"],
      nextAction: { key: "add_documents", label: "Legg til dokumenter", targetView: "documents" },
      counts: { totalDocuments, readyDocuments, unresolvedControlDocuments, sourceObjects, pendingOcrPages, totalPages, processedPages },
    };
  }

  if (isImporting) {
    return {
      status: "importing",
      isReadyForCaseRoom: false,
      canAskInCaseRoom: false,
      title: "Saken klargjøres",
      body: "Evida leser dokumenter og bygger sporbare kilder.",
      missing: ["Import pågår"],
      nextAction: { key: "show_import_status", label: "Vis behandlingsstatus", targetView: "documents" },
      counts: { totalDocuments, readyDocuments, unresolvedControlDocuments, sourceObjects, pendingOcrPages, totalPages, processedPages },
    };
  }

  if (unresolvedControlDocuments > 0) {
    return {
      status: "needs_control",
      isReadyForCaseRoom: false,
      canAskInCaseRoom: false,
      title: "Kontroll kreves",
      body: `${unresolvedControlDocuments} dokumenter må vurderes før Saksrom kan åpnes.`,
      missing: [`${unresolvedControlDocuments} dokumenter trenger kontroll`],
      nextAction: { key: "start_control", label: "Start kontroll", targetView: "control" },
      counts: { totalDocuments, readyDocuments, unresolvedControlDocuments, sourceObjects, pendingOcrPages, totalPages, processedPages },
    };
  }

  if (sourceObjects === 0) {
    return {
      status: "needs_sources",
      isReadyForCaseRoom: false,
      canAskInCaseRoom: false,
      title: "Kildegrunnlag mangler",
      body: "Dokumentene er importert, men Evida mangler sporbare kildeutdrag.",
      missing: ["Ingen sporbare kilder"],
      nextAction: { key: "replace_or_review_documents", label: "Åpne kontroll", targetView: "control" },
      counts: { totalDocuments, readyDocuments, unresolvedControlDocuments, sourceObjects, pendingOcrPages, totalPages, processedPages },
    };
  }

  return {
    status: "ready",
    isReadyForCaseRoom: true,
    canAskInCaseRoom: true,
    title: "Saken er klar",
    body: "Evida har bygget sporbare kilder fra dokumentene. Du kan nå stille spørsmål i Saksrom.",
    missing: [],
    nextAction: { key: "open_case_room", label: "Åpne Saksrom", targetView: "caseRoom" },
    counts: { totalDocuments, readyDocuments, unresolvedControlDocuments, sourceObjects, pendingOcrPages, totalPages, processedPages },
  };
}
```

## `nextAction.ts`

```ts
import type { CaseReadiness } from "./caseReadiness";
import type { ViewKey } from "../../types";

export function getTargetViewForReadiness(readiness: CaseReadiness): ViewKey {
  return readiness.nextAction.targetView;
}

export function canNavigateToCaseRoom(readiness: CaseReadiness): boolean {
  return readiness.isReadyForCaseRoom;
}
```

## Review decision types

```ts
export type ReviewDecisionType =
  | "approve_as_source"
  | "reviewed_not_citable"
  | "exclude_from_case"
  | "replace_file"
  | "skip_duplicate";

export interface ReviewDecisionInput {
  documentId: string;
  decision: ReviewDecisionType;
  reason?: string;
}

export interface BulkReviewDecisionInput {
  documentIds: string[];
  decision: Exclude<ReviewDecisionType, "replace_file">;
  reason?: string;
}
```

## Source eligibility

```ts
export function canDocumentBecomeSource(document: DocumentSummary): boolean {
  return (document.source_count || 0) > 0;
}

export function canBulkApproveAsSource(documents: DocumentSummary[]): boolean {
  return documents.every(canDocumentBecomeSource);
}
```
